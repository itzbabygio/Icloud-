OllyLoc 1.0 - change your iPhone location from your PC. Free.
=========================================================================

WHAT IT IS
  A click-a-map app that makes your iPhone report a fake GPS position
  SYSTEM-WIDE. Not a preview, not one app: it replaces the location iOS
  itself hands out, so Maps, Find My, Snapchat, Instagram, Life360, BeReal,
  Tinder, Pokemon Go, weather apps, browser geolocation - every single app
  that asks the phone "where are you" - gets the fake spot.
  It uses Apple's own developer location-simulation channel through
  pymobiledevice3. No jailbreak, no $99 dev account, no subscription.

  Two link modes:
    USB    - cable plugged in, instant, always works
    Wi-Fi  - phone unplugged, same Wi-Fi network, cable only needed once
             to set it up. This is the "LiveLoc" experience, free.

WHAT YOU NEED
  - Windows PC + USB cable
  - Python 3.9+ with "Add python.exe to PATH" ticked
  - iPhone and PC on the same Wi-Fi (for cable-free mode)

ONE-TIME SETUP
  1. Run SETUP.bat  (installs pymobiledevice3 + pillow)
  2. On the iPhone: Settings > Privacy & Security > Developer Mode > ON
     (the toggle appears once the phone has been plugged in at least once)
     Then restart the iPhone and unlock it.
  3. Plug the iPhone in, tap "Trust" on the phone.
  4. Double-click RUN.bat  (it asks for Administrator - say yes, the device
     tunnel needs it)

USING IT - USB MODE
  1. Leave the link selector on "USB", click "Connect iPhone",
     wait for "connected - usb tunnel".
  2. Click the map, search a place, or double-click a Quick pick.
  3. "Teleport my iPhone here". Done - open Snapchat and check.

USING IT - WI-FI MODE (NO CABLE)
  1. Plug the cable in once. In the app press "Wi-Fi setup (plug in once)".
     That runs:  pymobiledevice3 lockdown wifi-connections on
     It tells iOS "this computer may reach me over the network".
  2. The app flips the selector to "Wi-Fi" and connects over the air.
     Wait for "connected - wifi tunnel".
  3. Unplug. The fake position keeps holding. You can teleport from the
     couch, and Maps/Snapchat/Find My keep showing wherever you put yourself.
  4. Requirements for it to keep working: same Wi-Fi network, phone awake
     (screen lock is fine, it just needs to be on the network), PC running.
     If it drops, hit "Connect iPhone" again - no cable needed.
  Note: Wi-Fi pairing only sticks while the phone trusts this computer
  (same pair record). Ran a restore? Redo the one-time step with the cable.
  Also, the tunnel is a local one - it needs the PC and phone on the same
  network. Reaching it from another city is what cloud services like LiveLoc
  sell; that needs a server box, not this app.

BUTTONS
  Connect iPhone           - opens the tunnel in the selected mode
  Wi-Fi setup (plug in once) - one-time EnableWifiConnections over USB
  Teleport my iPhone here  - sends the picked coords to the phone
  Back to real location    - clears the simulation, phone shows reality
  Fly there (animated)     - glides there in 10 steps instead of jumping
  Map: click = pick, drag = pan, wheel = zoom

GOOD TO KNOW
  - The fake position lives as long as the tunnel is up. Close the app and
    the phone usually snaps back to reality; if not, press "Back to real
    location" first.
  - Every iOS update can break the tool. Fix:
    python -m pip install --upgrade pymobiledevice3
  - Do not sell your own version of this. Apple kills certs/pairings over it,
    App Store bans it, payment processors drop it. Personal use only.

TROUBLESHOOTING
  "tunnel failed" / no RSD address - run RUN.bat as Administrator, unlock
      the phone, Developer Mode ON, replug the cable.
  "DeveloperMode is disabled" - turn on Developer Mode and restart.
  "DeviceLocked" - unlock the phone, keep the screen on.
  "pymobiledevice3 not found" - run SETUP.bat again.
  Wi-Fi mode fails - phone and PC on the same network? Wi-Fi setup done once
      with the cable? Try "Connect iPhone" again; if it still fails, redo
      Wi-Fi setup plugged in. Some corporate/guest Wi-Fi blocks device-to-
      device traffic.
  Window says DEMO mode - the tool wasn't found, run SETUP.bat.

FILES
  ollyloc.py       the app
  setup.bat        one-time install
  run.bat          launch (self-elevates)
  requirements.txt
