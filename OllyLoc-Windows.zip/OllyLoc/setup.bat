@echo off
rem One-time setup for OllyLoc on Windows
echo === OllyLoc setup ===
where python >nul 2>&1
if errorlevel 1 (
  echo Python is not installed.
  echo Install it from https://www.python.org/downloads/ and TICK "Add python.exe to PATH", then run this again.
  pause
  exit /b
)
echo Installing python packages (pymobiledevice3, pillow)...
python -m pip install --upgrade pip
python -m pip install pymobiledevice3 pillow
echo.
echo Checking the tool answers...
python -m pymobiledevice3 version
echo.
echo Setup done. Double-click RUN.bat to start OllyLoc.
pause
