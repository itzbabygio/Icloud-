#!/usr/bin/env python3
"""OllyLoc 1.0 - pick a spot on the map, your iPhone goes there.

Wraps pymobiledevice3, which talks to Apple's own developer
location-simulation channel. No jailbreak, no subscription, no cloud.

Windows: run RUN.bat (it self-elevates, the tunnel needs admin).
"""
import io
import json
import math
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request

import tkinter as tk
from tkinter import ttk, messagebox
from tkinter.scrolledtext import ScrolledText

try:
    from PIL import Image, ImageTk
    HAVE_PIL = True
except Exception:
    HAVE_PIL = False

APP = "OllyLoc 1.0"
UA = {"User-Agent": "OllyLoc/1.0 (personal iPhone location simulator)"}
TILE_URL = "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
CACHE_DIR = os.path.join(os.path.expanduser("~"), ".ollyloc", "tiles")
NOMINATIM = "https://nominatim.openstreetmap.org/search"

PRESETS = [
    ("Dubai", 25.2048, 55.2708), ("Paris", 48.8566, 2.3522),
    ("Miami", 25.7617, -80.1918), ("New York", 40.7128, -74.0060),
    ("Los Angeles", 34.0522, -118.2437), ("Las Vegas", 36.1699, -115.1398),
    ("London", 51.5074, -0.1278), ("Monaco", 43.7384, 7.4246),
    ("Tokyo", 35.6762, 139.6503), ("Bangkok", 13.7563, 100.5018),
    ("Bali", -8.4095, 115.1889), ("Sydney", -33.8688, 151.2093),
    ("Rio de Janeiro", -22.9068, -43.1729), ("Istanbul", 41.0082, 28.9784),
    ("Chesapeake VA (home)", 36.7682, -76.2875),
]

BG = "#0e1116"
PANEL = "#161b22"
FG = "#e6edf3"
MUTED = "#8b949e"
ACCENT = "#2f81f7"
GOOD = "#3fb950"
BAD = "#f85149"


def log_safe(*a):
    print(*a, flush=True)


# ---------------------------------------------------------------- map maths
def project(lat, lon, z):
    """lat/lon -> global pixel coords at zoom z"""
    n = 256.0 * (2 ** z)
    lat = max(min(lat, 85.05112878), -85.05112878)
    x = (lon + 180.0) / 360.0 * n
    s = math.sin(math.radians(lat))
    y = (0.5 - math.log((1 + s) / (1 - s)) / (4 * math.pi)) * n
    return x, y


def unproject(x, y, z):
    n = 256.0 * (2 ** z)
    lon = x / n * 360.0 - 180.0
    lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))
    return lat, lon


class TilePool:
    """background tile down-loader with an on-disk cache"""

    def __init__(self, out_queue):
        self.q = out_queue
        self.jobs = queue.Queue()
        self.busy = set()
        self.lock = threading.Lock()
        os.makedirs(CACHE_DIR, exist_ok=True)
        for _ in range(6):
            t = threading.Thread(target=self._work, daemon=True)
            t.start()

    def request(self, z, x, y):
        key = (z, x, y)
        with self.lock:
            if key in self.busy:
                return
            self.busy.add(key)
        self.jobs.put(key)

    def _work(self):
        while True:
            z, x, y = self.jobs.get()
            key = (z, x, y)
            path = os.path.join(CACHE_DIR, str(z), str(x), "%d.png" % y)
            data = None
            if os.path.exists(path):
                try:
                    with open(path, "rb") as f:
                        data = f.read()
                except Exception:
                    data = None
            if data is None:
                try:
                    req = urllib.request.Request(TILE_URL.format(z=z, x=x, y=y), headers=UA)
                    with urllib.request.urlopen(req, timeout=12) as r:
                        data = r.read()
                    os.makedirs(os.path.dirname(path), exist_ok=True)
                    with open(path, "wb") as f:
                        f.write(data)
                except Exception:
                    data = None
            self.q.put(("tile", key, data))
            with self.lock:
                self.busy.discard(key)


class MapView(tk.Frame):
    TILE = 256
    MINZ, MAXZ = 2, 17

    def __init__(self, master, on_pick=None, on_center=None):
        super().__init__(master, bg=BG)
        self.canvas = tk.Canvas(self, bg=BG, highlightthickness=0, cursor="crosshair")
        self.canvas.pack(fill="both", expand=True)
        self.on_pick = on_pick
        self.on_center = on_center
        self.lat, self.lon, self.zoom = 26.0, 10.0, 2
        self.tiles = {}
        self.images = []
        self.marker = None
        self.q = queue.Queue()
        self.pool = TilePool(self.q)
        self._drag = None
        self._moved = False
        self.canvas.bind("<Configure>", lambda e: self.redraw())
        self.canvas.bind("<ButtonPress-1>", self._press)
        self.canvas.bind("<B1-Motion>", self._motion)
        self.canvas.bind("<ButtonRelease-1>", self._release)
        self.canvas.bind("<MouseWheel>", self._wheel)
        self.canvas.bind("<Button-4>", lambda e: self._zoom(1))
        self.canvas.bind("<Button-5>", lambda e: self._zoom(-1))
        self.canvas.bind("<Double-Button-1>", lambda e: self._zoom(1))
        self.after(60, self._drain)

    # ---- view helpers
    def _dims(self):
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        return (w if w > 10 else 800), (h if h > 10 else 600)

    def _origin(self):
        w, h = self._dims()
        cx, cy = project(self.lat, self.lon, self.zoom)
        return cx - w / 2.0, cy - h / 2.0

    def goto(self, lat, lon, zoom=None, mark=True):
        self.lat, self.lon = float(lat), float(lon)
        if zoom is not None:
            self.zoom = max(self.MINZ, min(self.MAXZ, int(zoom)))
        if mark:
            self.marker = (float(lat), float(lon))
        self.redraw()

    def set_marker(self, lat, lon):
        self.marker = (float(lat), float(lon))
        self.redraw()

    def _zoom(self, delta, anchor=None):
        old = self.zoom
        self.zoom = max(self.MINZ, min(self.MAXZ, self.zoom + delta))
        if self.zoom == old:
            return
        self.redraw()

    def _wheel(self, event):
        self._zoom(1 if event.delta > 0 else -1)

    def _press(self, event):
        self._drag = (event.x, event.y, self.lat, self.lon)
        self._moved = False

    def _motion(self, event):
        if not self._drag:
            return
        x0, y0, lat0, lon0 = self._drag
        dx, dy = event.x - x0, event.y - y0
        if abs(dx) + abs(dy) > 3:
            self._moved = True
        cx, cy = project(lat0, lon0, self.zoom)
        self.lat, self.lon = unproject(cx - dx, cy - dy, self.zoom)
        self.redraw()

    def _release(self, event):
        if not self._drag:
            return
        self._drag = None
        if not self._moved:
            ox, oy = self._origin()
            lat, lon = unproject(ox + event.x, oy + event.y, self.zoom)
            self.marker = (lat, lon)
            self.redraw()
            if self.on_pick:
                self.on_pick(lat, lon)
        elif self.on_center:
            self.on_center(self.lat, self.lon)

    # ---- drawing
    def _drain(self):
        made = 0
        while made < 24:
            try:
                kind, key, data = self.q.get_nowait()
            except queue.Empty:
                break
            made += 1
            if data and HAVE_PIL:
                try:
                    im = Image.open(io.BytesIO(data)).convert("RGB")
                    self.tiles[key] = ImageTk.PhotoImage(im)
                except Exception:
                    self.tiles[key] = False
            else:
                self.tiles[key] = False
        if made:
            self.redraw()
        self.after(90, self._drain)

    def redraw(self):
        c = self.canvas
        c.delete("all")
        w, h = self._dims()
        n = 2 ** self.zoom
        ox, oy = self._origin()
        tx0 = int(math.floor(ox / self.TILE))
        tx1 = int(math.floor((ox + w) / self.TILE))
        ty0 = int(math.floor(oy / self.TILE))
        ty1 = int(math.floor((oy + h) / self.TILE))
        self.images = []
        for tx in range(tx0, tx1 + 1):
            for ty in range(ty0, ty1 + 1):
                if ty < 0 or ty >= n:
                    continue
                key = (self.zoom, tx % n, ty)
                img = self.tiles.get(key)
                sx = tx * self.TILE - ox
                sy = ty * self.TILE - oy
                if isinstance(img, bool) or img is None:
                    if img is None:
                        self.pool.request(*key)
                    c.create_rectangle(sx, sy, sx + self.TILE, sy + self.TILE,
                                       fill="#12181f", outline="#1b2430")
                    continue
                c.create_image(sx, sy, image=img, anchor="nw")
                self.images.append(img)
        c.create_text(12, h - 14, anchor="w", fill=MUTED,
                      text="zoom %d  ·  %s" % (self.zoom, "click map to pick a spot · drag to pan · wheel to zoom"))
        if self.marker:
            mx, my = project(self.marker[0], self.marker[1], self.zoom)
            px, py = mx - ox, my - oy
            c.create_oval(px - 13, py - 13, px + 13, py + 13, outline=ACCENT, width=2)
            c.create_line(px - 22, py, px + 22, py, fill=ACCENT, width=1)
            c.create_line(px, py - 22, px, py + 22, fill=ACCENT, width=1)
            c.create_oval(px - 4, py - 4, px + 4, py + 4, fill=ACCENT, outline="")
            c.create_text(px + 18, py - 18, anchor="w", fill=FG,
                          text="%.4f, %.4f" % self.marker)


# ---------------------------------------------------------------- engine
class Engine:
    """drives pymobiledevice3"""

    def __init__(self, log):
        self.log = log
        self.tunnel = None
        self.rsd = None
        self.spoof = None
        self.demo = os.environ.get("OLLYLOC_DEMO") == "1"
        self.mode = "usb"          # "usb" or "wifi"
        self.exe = self._find()
        if not self.exe:
            self.demo = True
            log("pymobiledevice3 not found - running in DEMO mode (no device)")

    def _find(self):
        for n in ("pymobiledevice3", "pymobiledevice3.exe"):
            p = shutil.which(n)
            if p:
                return [p]
        try:
            r = subprocess.run([sys.executable, "-m", "pymobiledevice3", "--help"],
                               capture_output=True, timeout=25)
            if r.returncode == 0:
                return [sys.executable, "-m", "pymobiledevice3"]
        except Exception:
            pass
        return None

    def _flags(self):
        if os.name == "nt":
            return 0x08000000  # CREATE_NO_WINDOW
        return 0

    def _run(self, args, timeout=90):
        try:
            r = subprocess.run(self.exe + args, capture_output=True, text=True,
                               timeout=timeout, creationflags=self._flags())
            return r.returncode, (r.stdout or "") + (r.stderr or "")
        except Exception as e:
            return 1, str(e)

    # ---- setup steps
    def mount_ddi(self):
        if self.demo:
            self.log("DEMO: skipping developer disk image mount")
            return True
        rc, out = self._run(["mounter", "auto-mount"])
        self.log("mount: " + out.strip().splitlines()[-1] if out.strip() else "mount: done")
        return rc == 0

    # ---- wifi support -------------------------------------------------
    def enable_wifi(self):
        """one-time: allow this PC to reach the device over Wi-Fi (needs cable)"""
        if self.demo:
            self.log("DEMO: wifi connections enabled")
            return True, "demo"
        rc, out = self._run(["lockdown", "wifi-connections", "on"], timeout=90)
        txt = " ".join(out.split())[:160]
        self.log("wifi-connections on (rc=%s) %s" % (rc, txt))
        return rc == 0, out

    def wifi_state(self):
        if self.demo:
            return "demo"
        rc, out = self._run(["lockdown", "wifi-connections"], timeout=60)
        return " ".join(out.split())[:120]

    @staticmethod
    def _parse_rsd(line):
        """understand both the labeled output and --script-mode output"""
        m = re.search(r"RSD Address:\s*(\S+)", line)
        if m:
            return m.group(1), None
        m = re.search(r"RSD Port:\s*(\d+)", line)
        if m:
            return None, m.group(1)
        m = re.match(r"^\s*([0-9a-fA-F:\.\-]+|\d+\.\d+\.\d+\.\d+)\s+(\d{2,5})\s*$", line)
        if m:
            return m.group(1), m.group(2)
        return None, None

    def start_tunnel(self, done, mode=None):
        mode = mode or self.mode
        self.mode = mode
        if self.demo:
            self.rsd = ("demo", "0")
            self.log("DEMO tunnel up (%s)" % mode)
            done(True, "demo")
            return
        if self.tunnel and self.tunnel.poll() is None:
            self.stop_tunnel()
        if mode == "wifi":
            self.log("Wi-Fi mode: making sure Wi-Fi pairing is allowed...")
            self.enable_wifi()
            self.log("opening Wi-Fi tunnel (phone can stay unplugged)")
        else:
            self.log("opening USB tunnel (needs admin)...")
        args = ["remote", "start-tunnel", "-t", ("wifi" if mode == "wifi" else "usb"),
                "--script-mode"]
        try:
            self.tunnel = subprocess.Popen(
                self.exe + args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1, creationflags=self._flags())
        except Exception as e:
            self.log("tunnel failed: %s" % e)
            done(False, str(e))
            return
        addr, port = None, None
        tail = []
        t0 = time.time()
        for line in self.tunnel.stdout:
            line = line.rstrip()
            if not line:
                continue
            if re.search(r"(?i)error|traceback|exception|refused|timed out", line):
                tail.append(line)
                self.log("tunnel: " + line[:220])
            a, p = self._parse_rsd(line)
            if a:
                addr = a
            if p:
                port = p
            if addr and port:
                self.rsd = (addr, port)
                self.log("tunnel up (%s): %s %s" % (mode, addr, port))
                done(True, "%s %s" % (addr, port))
                addr = port = None
            if not self.rsd and time.time() - t0 > 60:
                break
        if not self.rsd:
            done(False, "\n".join(tail[-6:]) or "no RSD address from the tunnel")

    def stop_tunnel(self):
        if self.tunnel and self.tunnel.poll() is None:
            try:
                self.tunnel.terminate()
            except Exception:
                pass
        self.tunnel = None
        self.rsd = None

    # ---- the actual spoof
    def set_location(self, lat, lon):
        if self.demo:
            self.log("DEMO: teleported to %.5f, %.5f" % (lat, lon))
            return True, "demo"
        if not self.rsd:
            return False, "no tunnel"
        self._kill_spoof()
        addr, port = self.rsd
        try:
            self.spoof = subprocess.Popen(
                self.exe + ["developer", "dvt", "simulate-location", "set",
                            "--rsd", addr, port, "--", "%.6f" % lat, "%.6f" % lon],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                bufsize=1, creationflags=self._flags())
        except Exception as e:
            return False, str(e)
        time.sleep(0.9)
        if self.spoof.poll() not in (None, 0):
            try:
                err = (self.spoof.stdout.read() or "").strip()
            except Exception:
                err = ""
            return False, err or "set failed"
        self.log("location set: %.5f, %.5f" % (lat, lon))
        return True, "ok"

    def _kill_spoof(self):
        if self.spoof:
            try:
                self.spoof.terminate()
                self.spoof.wait(timeout=4)
            except Exception:
                try:
                    self.spoof.kill()
                except Exception:
                    pass
            self.spoof = None

    def clear(self):
        self._kill_spoof()
        if self.demo:
            self.log("DEMO: back to real location")
            return True, "demo"
        if not self.rsd:
            return False, "no tunnel"
        addr, port = self.rsd
        rc, out = self._run(["developer", "dvt", "simulate-location", "clear",
                             "--rsd", addr, port], timeout=45)
        self.log("cleared (rc=%s)" % rc)
        return rc == 0, out

    def alive(self):
        return bool(self.rsd) or self.demo


# ---------------------------------------------------------------- app
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP)
        self.geometry("1180x760")
        self.minsize(980, 640)
        self.configure(bg=BG)
        self.engine = Engine(self.log)
        self.last_marker = None
        self._build()

    # ---- ui
    def _build(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("TButton", padding=6)
        style.configure("Go.TButton", padding=9, font=("Segoe UI", 11, "bold"))
        style.configure("TCheckbutton", background=PANEL, foreground=FG)

        top = tk.Frame(self, bg=PANEL, height=58)
        top.pack(fill="x", side="top")
        top.pack_propagate(False)
        tk.Label(top, text="OllyLoc", bg=PANEL, fg=FG,
                 font=("Segoe UI", 17, "bold")).pack(side="left", padx=(14, 8), pady=10)
        tk.Label(top, text="system-wide GPS · every app · USB or Wi-Fi", bg=PANEL,
                 fg=MUTED, font=("Segoe UI", 9)).pack(side="left")
        self.status = tk.Label(top, text="● disconnected", bg=PANEL, fg=BAD,
                               font=("Segoe UI", 10, "bold"))
        self.status.pack(side="right", padx=14)
        ttk.Button(top, text="Connect iPhone", command=self.connect).pack(side="right", padx=6, pady=12)
        ttk.Button(top, text="Back to real location", command=self.back_real).pack(side="right", pady=12)

        mframe = tk.Frame(top, bg=PANEL)
        mframe.pack(side="right", padx=(4, 10), pady=12)
        tk.Label(mframe, text="link:", bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 9)).pack(side="left", padx=(0, 4))
        self.mode_var = tk.StringVar(value="usb")
        for txt, val in (("USB", "usb"), ("Wi-Fi", "wifi")):
            tk.Radiobutton(mframe, text=txt, value=val, variable=self.mode_var,
                           command=self._mode_changed, bg=PANEL, fg=FG,
                           selectcolor="#0d1117", activebackground=PANEL,
                           activeforeground=FG, highlightthickness=0,
                           font=("Segoe UI", 9)).pack(side="left")

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True)

        left = tk.Frame(body, bg=PANEL, width=312)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)

        def head(t):
            tk.Label(left, text=t.upper(), bg=PANEL, fg=MUTED,
                     font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=14, pady=(14, 2))

        head("search a place")
        row = tk.Frame(left, bg=PANEL)
        row.pack(fill="x", padx=14)
        self.q = tk.Entry(row, bg="#0d1117", fg=FG, insertbackground=FG,
                          relief="flat", font=("Segoe UI", 10))
        self.q.pack(side="left", fill="x", expand=True, ipady=5)
        self.q.bind("<Return>", lambda e: self.search())
        ttk.Button(row, text="Find", width=6, command=self.search).pack(side="left", padx=(6, 0))
        self.results = self._listbox(left, 6)
        self.results.bind("<Double-Button-1>", self.pick_result)
        self.results.bind("<Return>", self.pick_result)

        head("quick picks")
        self.presets = self._listbox(left, 8)
        for name, _, _ in PRESETS:
            self.presets.insert("end", "  " + name)
        self.presets.bind("<Double-Button-1>", self.pick_preset)
        self.presets.bind("<Return>", self.pick_preset)

        head("coordinates")
        crow = tk.Frame(left, bg=PANEL)
        crow.pack(fill="x", padx=14)
        tk.Label(crow, text="Lat", bg=PANEL, fg=MUTED).pack(side="left")
        self.lat_var = tk.StringVar()
        tk.Entry(crow, textvariable=self.lat_var, width=11, bg="#0d1117", fg=FG,
                 insertbackground=FG, relief="flat").pack(side="left", ipady=4, padx=(4, 10))
        tk.Label(crow, text="Lon", bg=PANEL, fg=MUTED).pack(side="left")
        self.lon_var = tk.StringVar()
        tk.Entry(crow, textvariable=self.lon_var, width=11, bg="#0d1117", fg=FG,
                 insertbackground=FG, relief="flat").pack(side="left", ipady=4, padx=4)

        self.fly = tk.BooleanVar(value=False)
        ttk.Checkbutton(left, text="Fly there (animated)", variable=self.fly).pack(anchor="w", padx=12, pady=(10, 0))

        self.go = ttk.Button(left, text="Teleport my iPhone here", style="Go.TButton", command=self.teleport)
        self.go.pack(fill="x", padx=14, pady=(12, 6))
        self.wifi_btn = ttk.Button(left, text="Wi-Fi setup (plug in once)",
                                   command=self.wifi_setup)
        self.wifi_btn.pack(fill="x", padx=14)

        head("recent")
        self.recent = self._listbox(left, 5)
        self.recent.bind("<Double-Button-1>", self.pick_recent)

        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="both", expand=True)
        self.map = MapView(right, on_pick=self.on_pick, on_center=self.on_center)
        self.map.pack(fill="both", expand=True)
        self.logbox = ScrolledText(right, height=7, bg="#0b0f14", fg="#9fb3c8",
                                   relief="flat", font=("Consolas", 9), insertbackground=FG)
        self.logbox.pack(fill="x")
        self.logbox.configure(state="disabled")

    def _listbox(self, parent, h):
        f = tk.Frame(parent, bg=PANEL)
        f.pack(fill="x", padx=14, pady=(2, 0))
        lb = tk.Listbox(f, height=h, bg="#0d1117", fg=FG, relief="flat",
                        highlightthickness=0, activestyle="none",
                        selectbackground=ACCENT, font=("Segoe UI", 9))
        lb.pack(side="left", fill="x", expand=True)
        sb = tk.Scrollbar(f, command=lb.yview, width=10)
        sb.pack(side="right", fill="y")
        lb.configure(yscrollcommand=sb.set)
        return lb

    def log(self, msg):
        def _do():
            self.logbox.configure(state="normal")
            self.logbox.insert("end", time.strftime("[%H:%M:%S] ") + str(msg) + "\n")
            self.logbox.see("end")
            self.logbox.configure(state="disabled")
        try:
            self.after(0, _do)
        except Exception:
            log_safe(msg)

    # ---- device
    def _mode_changed(self):
        mode = self.mode_var.get()
        self.engine.mode = mode
        if mode == "wifi":
            self.log("mode: Wi-Fi (no cable). One-time step: plug the phone in, hit "
                     "'Wi-Fi setup', then unplug.")
        else:
            self.log("mode: USB (cable)")
        if self.engine.rsd:
            self.connect()

    def connect(self):
        mode = self.mode_var.get()
        self.status.configure(text="● connecting (%s)..." % mode, fg="#d29922")
        self.log("--- connecting over %s ---" % mode)
        self.engine.mount_ddi()
        def done(ok, info):
            if ok:
                self.status.configure(text="● connected · %s tunnel" % mode, fg=GOOD)
                self.log("ready. position changes apply to the whole phone - every app.")
                if mode == "usb":
                    self.log("tip: unplugging ends it. Switch to Wi-Fi mode for cable-free.")
            else:
                self.status.configure(text="● tunnel failed (%s)" % mode, fg=BAD)
                self.log("tunnel failed: " + str(info))
                if mode == "usb":
                    self.log("check: phone unlocked, Developer Mode ON, run as Administrator")
                else:
                    self.log("wifi check: same Wi-Fi network, USB setup done once, phone awake, "
                             "run as Administrator")
        threading.Thread(target=self.engine.start_tunnel, args=(done, mode), daemon=True).start()

    def wifi_setup(self):
        self.log("--- Wi-Fi one-time setup (keep the cable plugged in) ---")
        def work():
            ok, out = self.engine.enable_wifi()
            def back():
                if ok:
                    self.log("Wi-Fi pairing allowed. Now pick the Wi-Fi link option and hit "
                             "Connect, then you can unplug.")
                    self.mode_var.set("wifi")
                    self._mode_changed()
                else:
                    self.log("Wi-Fi setup failed: " + str(out)[:220])
            self.after(0, back)
        threading.Thread(target=work, daemon=True).start()

    def back_real(self):
        ok, info = self.engine.clear()
        self.map.marker = None
        self.map.redraw()
        self.status.configure(text="● connected · real location" if ok else self.status.cget("text"),
                              fg=GOOD if ok else BAD)
        if not ok:
            self.log("clear failed: " + str(info)[:200])

    # ---- picking
    def on_pick(self, lat, lon):
        self.lat_var.set("%.6f" % lat)
        self.lon_var.set("%.6f" % lon)
        self.last_marker = (lat, lon)

    def on_center(self, lat, lon):
        pass

    def pick_preset(self, event=None):
        sel = self.presets.curselection()
        if not sel:
            return
        name, lat, lon = PRESETS[sel[0]]
        self.map.goto(lat, lon, 12)
        self.on_pick(lat, lon)
        self.log("picked %s" % name)

    def pick_recent(self, event=None):
        sel = self.recent.curselection()
        if not sel:
            return
        txt = self.recent.get(sel[0]).strip()
        try:
            lat, lon = [float(v) for v in txt.replace(",", " ").split()[:2]]
        except Exception:
            return
        self.map.goto(lat, lon, 12)
        self.on_pick(lat, lon)

    def pick_result(self, event=None):
        sel = self.results.curselection()
        if not sel:
            return
        lat, lon, label = self._found[sel[0]]
        self.map.goto(lat, lon, 13)
        self.on_pick(lat, lon)
        self.log("found: " + label)

    def search(self):
        q = self.q.get().strip()
        if not q:
            return
        self.results.delete(0, "end")
        self.results.insert("end", "  searching...")
        def work():
            try:
                url = NOMINATIM + "?" + urllib.parse.urlencode(
                    {"q": q, "format": "json", "limit": 8})
                req = urllib.request.Request(url, headers=UA)
                with urllib.request.urlopen(req, timeout=15) as r:
                    data = json.loads(r.read().decode("utf-8", "replace"))
            except Exception as e:
                data = []
                self.log("search error: %s" % e)
            def show():
                self.results.delete(0, "end")
                self._found = []
                for item in data:
                    try:
                        lat, lon = float(item["lat"]), float(item["lon"])
                    except Exception:
                        continue
                    label = item.get("display_name", "?")[:70]
                    self._found.append((lat, lon, label))
                    self.results.insert("end", "  " + label)
                if not self._found:
                    self.results.insert("end", "  no results")
            self.after(0, show)
        threading.Thread(target=work, daemon=True).start()

    # ---- the money button
    def teleport(self):
        try:
            lat = float(self.lat_var.get())
            lon = float(self.lon_var.get())
        except ValueError:
            if self.map.marker:
                lat, lon = self.map.marker
            else:
                messagebox.showinfo(APP, "Pick a spot on the map or type coordinates first.")
                return
        if not self.engine.alive():
            if messagebox.askyesno(APP, "Not connected to the iPhone yet. Connect now?"):
                self.connect()
            return
        if self.fly.get() and self.map.marker:
            threading.Thread(target=self._fly, args=(lat, lon), daemon=True).start()
        else:
            threading.Thread(target=self._send, args=(lat, lon), daemon=True).start()

    def _send(self, lat, lon):
        ok, info = self.engine.set_location(lat, lon)
        def done():
            if ok:
                self.map.set_marker(lat, lon)
                self.lat_var.set("%.6f" % lat)
                self.lon_var.set("%.6f" % lon)
                self.status.configure(text="● spoofing %.4f, %.4f" % (lat, lon), fg=GOOD)
                self.recent.insert(0, "  %.5f, %.5f" % (lat, lon))
                if self.recent.size() > 40:
                    self.recent.delete(39, "end")
            else:
                self.log("teleport failed: " + str(info)[:240])
                self.status.configure(text="● error", fg=BAD)
        self.after(0, done)

    def _fly(self, lat, lon):
        slat, slon = self.map.marker
        steps = 10
        for i in range(1, steps + 1):
            f = i / float(steps)
            a = slat + (lat - slat) * f
            b = slon + (lon - slon) * f
            self.engine.set_location(a, b)
            self.after(0, lambda a=a, b=b: (self.map.set_marker(a, b),
                                            self.status.configure(
                                                text="● flying... %.3f, %.3f" % (a, b), fg="#d29922")))
            time.sleep(0.55)
        self.after(0, lambda: self._send(lat, lon))


def main():
    if not HAVE_PIL:
        print("Pillow missing: pip install pillow", file=sys.stderr)
    app = App()
    if os.environ.get("OLLYLOC_DEMO") == "1":
        app.log("DEMO mode: no device needed. Click the map and hit Teleport.")
    app.mainloop()


if __name__ == "__main__":
    main()
