@echo off
rem OllyLoc - starts the app as Administrator (the device tunnel needs it)
cd /d "%~dp0"
net session >nul 2>&1
if %errorLevel% neq 0 (
  echo Asking for Administrator...
  powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
python ollyloc.py
if errorlevel 1 pause
